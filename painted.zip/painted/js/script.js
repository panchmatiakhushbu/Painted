/*menu js start*/

;(function($){
    'use strict';

    var defaults = {
        topOffset: 200,
        hideDuration: 300, 
        stickyClass: 'is-fixed'
    };

    $.fn.stickyPanel = function(options){ 
        if(this.length == 0) return this; 

        var self = this,
            settings,
            isFixed = false, 
            stickyClass,
            animation = {
                normal: self.css('animationDuration'), 
                getStyle: function (type) {
                    return {
                        animationDirection: type,
                        animationDuration: this[type]
                    };
                }
            };

        function init(){
            settings = $.extend({}, defaults, options);
            animation.reverse = settings.hideDuration + 'ms';
            stickyClass = settings.stickyClass;
            $(window).on('scroll', onScroll).trigger('scroll');
        }

        function onScroll() {
            if ( window.pageYOffset > settings.topOffset){
                if (!isFixed){
                    isFixed = true;
                    self.addClass(stickyClass)
                        .css(animation.getStyle('normal'));
                }
            } else {
                if (isFixed){
                    isFixed = false;

                    self.removeClass(stickyClass)
                        .each(function (index, e) {                            
                            void e.offsetWidth;
                        })
                        .addClass(stickyClass)
                        .css(animation.getStyle('reverse'));

                    setTimeout(function () {
                        self.removeClass(stickyClass);
                    }, settings.hideDuration);
                }
            }
        }

        init();

        return this;
    }
})(jQuery);


$(function () {
    $('#fixed').stickyPanel();
}); 

/*menu js end*/

/*Testnomial slider js start*/

(function () {
  "use strict";

  var carousels = function () {
    $(".owl-carousel1").owlCarousel({
      loop: true,
      center: true,
      margin: 0,
      autoplay: true,
      dots: false,
      responsiveClass: true,
      nav: false,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        680: {
          items: 2,
          nav: false,
          loop: false
        },
        1000: {
          items: 3,
          nav: true
        },
        1200: {
          items: 3,
          nav: true
        }
      }
    });
  };

  (function ($) {
    carousels();
  })(jQuery);
})();

/*Testnomial slider js end*/

/*chart js start*/
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: ["Loan Amount", "Total Interest Due"],
    datasets: [{
      backgroundColor: [        
        "#547BD2",
        "#3A2C68",       
      ],
      data: [5000000, 3050550]
    }]
  }
});


var ctx = document.getElementById("myChart1").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: ["Loan Amount", "Total Interest Due"],
    datasets: [{
      backgroundColor: [        
        "#547BD2",
        "#3A2C68",       
      ],
      data: [5000000, 3050550]
    }]
  }
});
/*chart js end*/

